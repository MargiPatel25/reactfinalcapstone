import { createFormContext } from "@mantine/form";

const initialValues = {
  seating: "",
  date: "",
  time: "",
  guests: "",
  occasion: "",
  firstName: "",
  lastName: "",
  email: "",
  phoneNumber: "",
  requests: "",
  accept: "",
};

const [FormProvider, useFormContext, useForm] =
  createFormContext();

const useBookingForm = () => {
  return { FormProvider, useFormContext, useForm };
};

export default useBookingForm;
