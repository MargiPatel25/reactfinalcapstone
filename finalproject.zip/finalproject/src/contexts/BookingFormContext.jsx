import React from "react";
import { BookingFormData, useBookingForm } from "src/hooks";
import { bookingFormValidation } from "src/validations";

const BookingFormContextProvider = ({ children }) => {
  const { FormProvider, useForm } = useBookingForm();

  const initialValues = {
    seating: "",
    date: "",
    time: "",
    guests: "",
    occasion: "",
    firstName: "",
    lastName: "",
    email: "",
    phoneNumber: "",
    requests: "",
    accept: "",
  };

  const form = useForm({
    initialValues,
    validate: bookingFormValidation,
  });

  return <FormProvider form={form}>{children}</FormProvider>;
};

export default BookingFormContextProvider;
