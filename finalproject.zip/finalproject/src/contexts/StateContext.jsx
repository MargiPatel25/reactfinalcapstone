import React, { createContext, useReducer } from 'react';
import * as Actions from 'src/store/actions';
import { initializeTimes, reducer } from 'src/store/reducers';
import { bookingFormValidation } from 'src/validations';
import { useBookingForm } from 'src/hooks';

const initialState = {
  openMenu: false,
  confirm: false,
  availableTimes: initializeTimes(),
  sending: false,
};

const BookingFormContextProvider = ({ children }) => {
  const { FormProvider, useForm } = useBookingForm();

  const initialValues = {
    seating: '',
    date: '',
    time: '',
    guests: '',
    occasion: '',
    firstName: '',
    lastName: '',
    email: '',
    phoneNumber: '',
    requests: '',
    accept: '',
  };

  const form = useForm({
    initialValues,
    validate: bookingFormValidation,
  });

  return <FormProvider form={form}>{children}</FormProvider>;
};

const StateContext = createContext({
  ...initialState,
  handleUpdateTimes: () => {},
  handleSwitchConfirmation: () => {},
  handleSendData: () => {},
  handleOpenMenu: () => {},
});

const StateContextProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState);

  const handleUpdateTimes = (date) => {
    dispatch(Actions.updateTimes(date));
  };

  const handleSwitchConfirmation = () => {
    dispatch(Actions.switchConfirmation());
  };

  const handleSendData = () => {
    dispatch(Actions.sendData());
  };

  const handleOpenMenu = () => {
    dispatch(Actions.openMenu());
  };

  const store = {
    openMenu: state.openMenu,
    availableTimes: state.availableTimes,
    confirm: state.confirm,
    sending: state.sending,
    handleUpdateTimes,
    handleSwitchConfirmation,
    handleSendData,
    handleOpenMenu,
  };

  return (
    <StateContext.Provider value={store}>{children}</StateContext.Provider>
  );
};

export { StateContext, StateContextProvider, BookingFormContextProvider };
