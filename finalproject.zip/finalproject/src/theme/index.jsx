export const colors = {
    primary: "#495e57",
    secondary: "#f4ce14",
    pink: "#ee9972",
    light: "#edefee",
    dark: "#333333",
  };
  