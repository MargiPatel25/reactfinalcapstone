import React from "react";
import { render, screen } from "@testing-library/react";
import { StateContextProvider } from "src/contexts";
import { ReservationsPage } from "src/pages";

const wrapper = ({ children }) => {
  return <StateContextProvider>{children}</StateContextProvider>;
};

test("Renders the page's header", () => {
  render(<ReservationsPage />, { wrapper });

  const headerElement = screen.getByText("Reservations");

  expect(headerElement).toBeInTheDocument();
});
