import {
  IconAlarm,
  IconCalendarDue,
  IconGlassFull,
  IconUser,
  TablerIcon,
} from "@tabler/icons";

const withTwoColors = (Component) => (props) => {
  return (
    <Component
      size={32}
      stroke={1.5}
      {...props}
      color={!props.value ? props.primary : props.secondary}
    />
  );
};

const DateIcon = withTwoColors(IconCalendarDue);
const DinersIcon = withTwoColors(IconUser);
const OccasionIcon = withTwoColors(IconGlassFull);
const TimeIcon = withTwoColors(IconAlarm);

export default function MyComponent() {
  return (
    <div>
      <DateIcon primary="#000" secondary="#fff" />
      <DinersIcon primary="#f00" secondary="#0f0" />
      <OccasionIcon primary="#00f" secondary="#ff0" />
      <TimeIcon primary="#0ff" secondary="#f0f" />
    </div>
  );
}
