import { Action } from "src/store/reducers";

export const ActionTypes = {
  OPEN_MENU: "OPEN_MENU",
  CHANGE_DATE: "CHANGE_DATE",
  SWITCH_CONFIRM: "SWITCH_CONFIRM",
  SENDING_DATA: "SENDING_DATA",
};

export const updateTimes = (date) => {
  return {
    type: ActionTypes.CHANGE_DATE,
    payload: date,
  };
};

export const switchConfirmation = () => {
  return {
    type: ActionTypes.SWITCH_CONFIRM,
  };
};

export const sendData = () => {
  return {
    type: ActionTypes.SENDING_DATA,
  };
};

export const openMenu = () => {
  return {
    type: ActionTypes.OPEN_MENU,
  };
};
